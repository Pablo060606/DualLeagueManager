"""Rutas del mercado de jugadores"""
from flask import Blueprint, render_template, request, jsonify, abort
from flask_login import login_required, current_user
from src.database.models import db, Player, Club, PlayerContract

bp = Blueprint('market', __name__, url_prefix='/market')

@bp.route('/players')
@login_required
def players():
    """Exploración del mercado de jugadores"""
    # Filtros
    position = request.args.get('position')
    league = request.args.get('league')
    search = request.args.get('search')
    
    query = Player.query.filter_by(status='available')
    
    if position:
        query = query.filter_by(position=position)
    
    if league:
        query = query.filter_by(league=league)
    
    if search:
        query = query.filter(Player.name.ilike(f'%{search}%'))
    
    players_list = query.all()
    
    can_interact = current_user.role == 'manager'

    # Obtener datos del club del usuario
    club = Club.query.filter_by(manager_id=current_user.id).first()
    squad_count = 0 if can_interact else None
    if club:
        squad_count = PlayerContract.query.filter_by(club_id=club.id).count()
    
    # Obtener listado de ligas y posiciones únicas
    all_leagues = db.session.query(Player.league).distinct().all()
    all_positions = db.session.query(Player.position).distinct().all()
    
    return render_template('market.html',
                         players=players_list,
                         current_position=position,
                         current_league=league,
                          current_search=search,
                          leagues=[l[0] for l in all_leagues],
                          positions=[p[0] for p in all_positions],
                          squad_count=squad_count,
                          can_interact=can_interact)

@bp.route('/api/players')
def api_players():
    """API: Obtener lista de jugadores disponibles"""
    position = request.args.get('position')
    league = request.args.get('league')
    
    query = Player.query.filter_by(status='available')
    
    if position:
        query = query.filter_by(position=position)
    if league:
        query = query.filter_by(league=league)
    
    players_list = query.all()
    
    return jsonify([{
        'id': p.id,
        'name': p.name,
        'position': p.position,
        'rating': p.rating,
        'value': p.value,
        'league': p.league,
        'status': p.status
    } for p in players_list])

@bp.route('/api/player/<int:player_id>')
def api_player_detail(player_id):
    """API: Obtener detalles de un jugador"""
    player = db.session.get(Player, player_id)
    if not player:
        abort(404)
    
    return jsonify({
        'id': player.id,
        'name': player.name,
        'position': player.position,
        'rating': player.rating,
        'value': player.value,
        'league': player.league,
        'status': player.status,
        'created_at': player.created_at.isoformat()
    })
