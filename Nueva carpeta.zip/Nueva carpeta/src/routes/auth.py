"""Rutas de autenticación"""
from datetime import datetime
from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from src.database.models import db, User, Player

bp = Blueprint('auth', __name__, url_prefix='/auth')

@bp.route('/register', methods=['GET', 'POST'])
def register():
    """Registro de nuevos usuarios"""
    if request.method == 'POST':
        email = (request.form.get('email') or '').strip().lower()
        password = request.form.get('password') or ''
        name = (request.form.get('name') or '').strip()
        role = (request.form.get('role') or 'manager').strip().lower()
        phone = (request.form.get('phone') or '').strip() or None
        city = (request.form.get('city') or '').strip() or None
        birth_date_raw = (request.form.get('birth_date') or '').strip()
        birth_date = None
        if birth_date_raw:
            try:
                birth_date = datetime.strptime(birth_date_raw, '%Y-%m-%d').date()
            except ValueError:
                flash('La fecha de nacimiento no es válida', 'error')
                return redirect(url_for('auth.register'))
        
        # Validaciones
        if not email or not password or not name:
            flash('Todos los campos son requeridos', 'error')
            return redirect(url_for('auth.register'))

        if role not in {'manager', 'player'}:
            flash('Rol inválido', 'error')
            return redirect(url_for('auth.register'))
        
        # Verificar si el usuario ya existe
        if User.query.filter_by(email=email).first():
            flash('El email ya está registrado', 'error')
            return redirect(url_for('auth.register'))
        
        # Crear nuevo usuario
        user = User(
            email=email,
            password=generate_password_hash(password),
            name=name,
            role=role,
            phone=phone,
            city=city,
            birth_date=birth_date
        )
        
        db.session.add(user)
        db.session.flush()

        if role == 'player':
            preferred_position = (request.form.get('preferred_position') or 'DEL').strip().upper()
            league = (request.form.get('league') or 'LaLiga').strip()

            player = Player(
                name=name,
                position=preferred_position if preferred_position in {'PG', 'DEF', 'MED', 'DEL'} else 'DEL',
                rating=6.0,
                value=1000000,
                league=league or 'LaLiga',
                status='available',
                user_id=user.id,
                release_clause=5000000
            )
            db.session.add(player)

        db.session.commit()
        
        flash('Usuario registrado exitosamente. Por favor, inicia sesión.', 'success')
        return redirect(url_for('auth.login'))
    
    return render_template('register.html')

@bp.route('/login', methods=['GET', 'POST'])
def login():
    """Inicio de sesión"""
    if current_user.is_authenticated:
        return redirect(url_for('clubs.dashboard'))
    
    if request.method == 'POST':
        email = (request.form.get('email') or '').strip().lower()
        password = request.form.get('password') or ''
        
        user = User.query.filter_by(email=email).first()
        
        if user and check_password_hash(user.password, password):
            login_user(user)
            flash(f'Bienvenido, {user.name}!', 'success')
            # Manejar redirección 'next' de forma segura
            from urllib.parse import urlparse, urljoin
            def is_safe_url(target):
                ref_url = urlparse(request.host_url)
                test_url = urlparse(urljoin(request.host_url, target))
                return test_url.scheme in ('http','https') and ref_url.netloc == test_url.netloc

            next_page = request.form.get('next') or request.args.get('next')
            if next_page and is_safe_url(next_page):
                # Evitar redirigir a endpoints que requieren POST (como /transfers/sign)
                if next_page.endswith('/transfers/sign'):
                    if user.role == 'player':
                        return redirect(url_for('market.players'))
                    return redirect(url_for('clubs.dashboard'))
                return redirect(next_page)

            if user.role == 'player':
                return redirect(url_for('market.players'))
            return redirect(url_for('clubs.dashboard'))
        else:
            flash('Email o contraseña incorrectos', 'error')
    
    return render_template('login.html')

@bp.route('/logout')
@login_required
def logout():
    """Cerrar sesión"""
    logout_user()
    flash('Has cerrado sesión exitosamente', 'success')
    return redirect(url_for('public.landing'))
