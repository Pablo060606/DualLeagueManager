"""Rutas públicas (sin autenticación)"""
from flask import Blueprint, render_template, request
from src.database.models import Club, Player, db

bp = Blueprint('public', __name__)

@bp.route('/')
def landing():
    """Página de inicio pública"""
    total_clubs = Club.query.count()
    total_players = Player.query.count()
    
    return render_template('public/landing.html', 
                         total_clubs=total_clubs,
                         total_players=total_players)

@bp.route('/clubs')
def clubs():
    """Exploración pública de clubes"""
    clubs_list = Club.query.all()
    return render_template('public/clubs.html', clubs=clubs_list)

@bp.route('/market')
def market():
    """Exploración pública del mercado"""
    position = request.args.get('position')
    league = request.args.get('league')
    search = request.args.get('search')

    query = Player.query.filter_by(status='available')

    if position:
        query = query.filter_by(position=position)
    if league:
        query = query.filter_by(league=league)
    if search:
        query = query.filter(Player.name.ilike(f'%{search}%'))

    players = query.all()

    # Conteo de plantilla no aplica en vista pública
    squad_count = None

    all_leagues = db.session.query(Player.league).distinct().all()
    all_positions = db.session.query(Player.position).distinct().all()

    return render_template('market.html',
                           players=players,
                           current_position=position,
                           current_league=league,
                            current_search=search,
                            leagues=[l[0] for l in all_leagues],
                            positions=[p[0] for p in all_positions],
                            squad_count=squad_count,
                            can_interact=False)
