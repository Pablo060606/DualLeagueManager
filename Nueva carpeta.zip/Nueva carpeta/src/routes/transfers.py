"""Rutas de fichajes y transferencias"""
from datetime import datetime, timedelta
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, abort
from flask_login import login_required, current_user
from src.database.models import (db, Club, Player, PlayerContract, MembershipRequest,
                                 Transaction)

bp = Blueprint('transfers', __name__, url_prefix='/transfers')


def _get_or_create_manager_club():
    if current_user.role != 'manager':
        return None, False
    club = Club.query.filter_by(manager_id=current_user.id).first()
    created = False
    if not club:
        desired_name = 'Ejemplo FC'
        if Club.query.filter_by(name=desired_name).first():
            desired_name = f'{desired_name} ({current_user.id})'
        club = Club(
            name=desired_name,
            manager_id=current_user.id,
            budget=0,
            available_budget=0
        )
        db.session.add(club)
        db.session.commit()
        created = True
    return club, created


def _active_contract_for_player(player_id):
    return PlayerContract.query.filter(
        PlayerContract.player_id == player_id,
        PlayerContract.end_date.is_(None)
    ).first()


def _assign_player_to_club(player, club, contract_type, amount, description):
    existing_contract = _active_contract_for_player(player.id)
    if existing_contract:
        db.session.delete(existing_contract)

    contract = PlayerContract(
        player_id=player.id,
        club_id=club.id,
        contract_type=contract_type,
        salary=0
    )
    player.status = 'signed'

    transaction = Transaction(
        club_id=club.id,
        player_id=player.id,
        transaction_type=contract_type if contract_type in {'sign', 'clause'} else 'sign',
        amount=amount,
        description=description
    )

    db.session.add(contract)
    db.session.add(transaction)

@bp.route('/sign', methods=['POST'])
@login_required
def sign_player():
    """Fichar un jugador"""
    if current_user.role != 'manager':
        flash('Solo los managers pueden fichar jugadores', 'error')
        return redirect(url_for('market.players'))

    player_id_raw = request.form.get('player_id')
    try:
        player_id = int(player_id_raw)
    except (TypeError, ValueError):
        flash('Jugador inválido', 'error')
        return redirect(url_for('market.players'))
    
    club, created = _get_or_create_manager_club()
    if created:
        flash(f'Club "{club.name}" creado automáticamente.', 'info')
    
    player = db.session.get(Player, player_id)
    if not player:
        abort(404)
    
    # Validaciones
    if player.status != 'available':
        flash('Este jugador no está disponible', 'error')
        return redirect(url_for('market.players'))
    
    # Verificar límite de jugadores (máximo 18)
    squad_count = PlayerContract.query.filter_by(club_id=club.id).count()
    if squad_count >= 18:
        flash('Tu plantilla está completa (máximo 18 jugadores)', 'error')
        return redirect(url_for('market.players'))
    
    # Presupuesto ilimitado: permitir fichar sin restricción
    # Crear contrato
    contract = PlayerContract(
        player_id=player.id,
        club_id=club.id,
        contract_type='free_agent',
        salary=0
    )
    
    # No se descuenta presupuesto (infinito)
    # Actualizar estado del jugador
    player.status = 'signed'
    
    # Crear transacción
    transaction = Transaction(
        club_id=club.id,
        player_id=player.id,
        transaction_type='sign',
        amount=player.value,
        description=f'Fichaje de {player.name}'
    )
    
    db.session.add(contract)
    db.session.add(transaction)
    db.session.commit()
    
    flash(f'{player.name} fichado exitosamente!', 'success')
    return redirect(url_for('clubs.squad', club_id=club.id))

@bp.route('/release/<int:player_id>', methods=['POST'])
@login_required
def release_player(player_id):
    """Liberar un jugador"""
    if current_user.role != 'manager':
        flash('Solo los managers pueden liberar jugadores', 'error')
        return redirect(url_for('market.players'))

    club = Club.query.filter_by(manager_id=current_user.id).first()
    if not club:
        flash('Debes crear un club primero', 'error')
        return redirect(url_for('clubs.create'))
    
    player = db.session.get(Player, player_id)
    if not player:
        abort(404)
    contract = PlayerContract.query.filter_by(
        player_id=player.id,
        club_id=club.id
    ).first()
    
    if not contract:
        flash('Este jugador no está en tu plantilla', 'error')
        return redirect(url_for('clubs.squad', club_id=club.id))
    
    # Devolver presupuesto
    club.available_budget += player.value
    
    # Cambiar estado del jugador
    player.status = 'available'
    
    # Eliminar contrato
    db.session.delete(contract)
    db.session.commit()
    
    flash(f'{player.name} liberado exitosamente!', 'success')
    return redirect(url_for('clubs.squad', club_id=club.id))

@bp.route('/requests')
@login_required
def requests_view():
    """Ver solicitudes entre club y jugador."""
    if current_user.role == 'manager':
        club = Club.query.filter_by(manager_id=current_user.id).first()
        if not club:
            flash('Debes crear un club primero', 'error')
            return redirect(url_for('clubs.create'))

        sent_requests = MembershipRequest.query.filter(
            MembershipRequest.club_id == club.id,
            MembershipRequest.initiated_by == 'club'
        ).order_by(MembershipRequest.created_at.desc()).all()
        received_requests = MembershipRequest.query.filter(
            MembershipRequest.club_id == club.id,
            MembershipRequest.initiated_by == 'player'
        ).order_by(MembershipRequest.created_at.desc()).all()
        clubs = []
        player_profiles = Player.query.filter(Player.user_id.isnot(None)).order_by(Player.name.asc()).all()
    else:
        player_profile = Player.query.filter_by(user_id=current_user.id).first()
        if not player_profile:
            flash('No tienes perfil de jugador', 'error')
            return redirect(url_for('market.players'))

        sent_requests = MembershipRequest.query.filter(
            MembershipRequest.player_id == player_profile.id,
            MembershipRequest.initiated_by == 'player'
        ).order_by(MembershipRequest.created_at.desc()).all()
        received_requests = MembershipRequest.query.filter(
            MembershipRequest.player_id == player_profile.id,
            MembershipRequest.initiated_by == 'club'
        ).order_by(MembershipRequest.created_at.desc()).all()
        clubs = Club.query.order_by(Club.name.asc()).all()
        player_profiles = []

    return render_template(
        'requests.html',
        sent_requests=sent_requests,
        received_requests=received_requests,
        clubs=clubs,
        player_profiles=player_profiles
    )


@bp.route('/requests/player-to-club', methods=['POST'])
@login_required
def create_player_to_club_request():
    """Jugador solicita unirse a un club."""
    if current_user.role != 'player':
        flash('Solo los jugadores pueden crear esta solicitud', 'error')
        return redirect(url_for('transfers.requests_view'))

    player_profile = Player.query.filter_by(user_id=current_user.id).first()
    if not player_profile:
        flash('No tienes perfil de jugador', 'error')
        return redirect(url_for('transfers.requests_view'))

    club_id_raw = request.form.get('club_id')
    try:
        club_id = int(club_id_raw)
    except (TypeError, ValueError):
        flash('Club inválido', 'error')
        return redirect(url_for('transfers.requests_view'))

    club = db.session.get(Club, club_id)
    if not club:
        abort(404)

    duplicate = MembershipRequest.query.filter_by(
        club_id=club.id,
        player_id=player_profile.id,
        initiated_by='player',
        request_kind='join_request',
        status='pending'
    ).first()
    if duplicate:
        flash('Ya existe una solicitud pendiente para ese club', 'info')
        return redirect(url_for('transfers.requests_view'))

    req = MembershipRequest(
        club_id=club.id,
        player_id=player_profile.id,
        initiated_by='player',
        request_kind='join_request',
        status='pending'
    )
    db.session.add(req)
    db.session.commit()
    flash('Solicitud enviada al club', 'success')
    return redirect(url_for('transfers.requests_view'))


@bp.route('/requests/club-to-player', methods=['POST'])
@login_required
def create_club_to_player_request():
    """Club solicita incorporación de un jugador."""
    if current_user.role != 'manager':
        flash('Solo los managers pueden crear esta solicitud', 'error')
        return redirect(url_for('transfers.requests_view'))

    club = Club.query.filter_by(manager_id=current_user.id).first()
    if not club:
        flash('Debes crear un club primero', 'error')
        return redirect(url_for('clubs.create'))

    player_id_raw = request.form.get('player_id')
    try:
        player_id = int(player_id_raw)
    except (TypeError, ValueError):
        flash('Jugador inválido', 'error')
        return redirect(url_for('transfers.requests_view'))

    player = db.session.get(Player, player_id)
    if not player or not player.user_id:
        flash('Solo puedes invitar jugadores registrados', 'error')
        return redirect(url_for('transfers.requests_view'))

    duplicate = MembershipRequest.query.filter_by(
        club_id=club.id,
        player_id=player.id,
        initiated_by='club',
        request_kind='club_invitation',
        status='pending'
    ).first()
    if duplicate:
        flash('Ya existe una invitación pendiente para este jugador', 'info')
        return redirect(url_for('transfers.requests_view'))

    req = MembershipRequest(
        club_id=club.id,
        player_id=player.id,
        initiated_by='club',
        request_kind='club_invitation',
        status='pending'
    )
    db.session.add(req)
    db.session.commit()
    flash('Solicitud enviada al jugador', 'success')
    return redirect(url_for('transfers.requests_view'))


@bp.route('/requests/precontract', methods=['POST'])
@login_required
def create_precontract_request():
    """Club solicita preacuerdo a jugador con menos de un año de contrato."""
    if current_user.role != 'manager':
        flash('Solo los managers pueden crear esta solicitud', 'error')
        return redirect(url_for('transfers.requests_view'))

    club = Club.query.filter_by(manager_id=current_user.id).first()
    if not club:
        flash('Debes crear un club primero', 'error')
        return redirect(url_for('clubs.create'))

    player_id_raw = request.form.get('player_id')
    try:
        player_id = int(player_id_raw)
    except (TypeError, ValueError):
        flash('Jugador inválido', 'error')
        return redirect(url_for('transfers.requests_view'))

    player = db.session.get(Player, player_id)
    if not player or not player.user_id:
        flash('Solo puedes solicitar preacuerdo a jugadores registrados', 'error')
        return redirect(url_for('transfers.requests_view'))

    active_contract = _active_contract_for_player(player.id)
    if not active_contract or not active_contract.end_date:
        flash('El jugador no tiene contrato con fecha fin definida', 'error')
        return redirect(url_for('transfers.requests_view'))

    if active_contract.end_date > (datetime.utcnow() + timedelta(days=365)):
        flash('Solo puedes solicitar preacuerdo si queda menos de un año de contrato', 'error')
        return redirect(url_for('transfers.requests_view'))

    req = MembershipRequest(
        club_id=club.id,
        player_id=player.id,
        initiated_by='club',
        request_kind='precontract',
        status='pending'
    )
    db.session.add(req)
    db.session.commit()
    flash('Preacuerdo enviado al jugador', 'success')
    return redirect(url_for('transfers.requests_view'))


@bp.route('/requests/<int:req_id>/respond', methods=['POST'])
@login_required
def respond_request(req_id):
    """Aceptar o rechazar solicitud según rol."""
    decision = (request.form.get('decision') or '').strip().lower()
    if decision not in {'accepted', 'rejected'}:
        flash('Decisión inválida', 'error')
        return redirect(url_for('transfers.requests_view'))

    req = db.session.get(MembershipRequest, req_id)
    if not req or req.status != 'pending':
        flash('Solicitud no encontrada o ya resuelta', 'error')
        return redirect(url_for('transfers.requests_view'))

    can_respond = False
    if current_user.role == 'manager':
        manager_club = Club.query.filter_by(manager_id=current_user.id).first()
        can_respond = bool(manager_club and req.club_id == manager_club.id and req.initiated_by == 'player')
    elif current_user.role == 'player':
        player_profile = Player.query.filter_by(user_id=current_user.id).first()
        can_respond = bool(player_profile and req.player_id == player_profile.id and req.initiated_by == 'club')

    if not can_respond:
        flash('No tienes permisos para responder esta solicitud', 'error')
        return redirect(url_for('transfers.requests_view'))

    req.status = decision
    req.response_date = datetime.utcnow()

    if decision == 'accepted':
        player = db.session.get(Player, req.player_id)
        club = db.session.get(Club, req.club_id)

        if req.request_kind in {'join_request', 'club_invitation'}:
            _assign_player_to_club(
                player=player,
                club=club,
                contract_type='sign',
                amount=player.value,
                description=f'Incorporación por solicitud ({req.request_kind}) de {player.name}'
            )
        elif req.request_kind == 'precontract':
            flash('Preacuerdo aceptado: incorporación al finalizar el contrato vigente', 'success')

    db.session.commit()
    flash('Solicitud actualizada', 'success')
    return redirect(url_for('transfers.requests_view'))


@bp.route('/clause/<int:player_id>/pay', methods=['POST'])
@login_required
def pay_release_clause(player_id):
    """Pagar cláusula de rescisión e incorporar automáticamente al jugador."""
    if current_user.role != 'manager':
        flash('Solo los managers pueden pagar cláusulas', 'error')
        return redirect(url_for('market.players'))

    club = Club.query.filter_by(manager_id=current_user.id).first()
    if not club:
        flash('Debes crear un club primero', 'error')
        return redirect(url_for('clubs.create'))

    player = db.session.get(Player, player_id)
    if not player:
        abort(404)

    if not player.release_clause or player.release_clause <= 0:
        flash('El jugador no tiene cláusula de rescisión definida', 'error')
        return redirect(url_for('transfers.requests_view'))

    _assign_player_to_club(
        player=player,
        club=club,
        contract_type='clause',
        amount=player.release_clause,
        description=f'Pago de cláusula de {player.name}'
    )
    db.session.commit()

    flash(f'Cláusula abonada: {player.name} se incorporó automáticamente', 'success')
    return redirect(url_for('clubs.squad', club_id=club.id))

@bp.route('/api/sign', methods=['POST'])
@login_required
def api_sign_player():
    """API: Fichar un jugador"""
    if current_user.role != 'manager':
        return jsonify({'error': 'Only managers can sign players'}), 403

    data = request.get_json(silent=True) or {}
    player_id = data.get('player_id')
    if player_id is None:
        return jsonify({'error': 'player_id is required'}), 400
    try:
        player_id = int(player_id)
    except (TypeError, ValueError):
        return jsonify({'error': 'player_id must be an integer'}), 400
    
    club, _ = _get_or_create_manager_club()
    
    player = db.session.get(Player, player_id)
    if not player:
        return jsonify({'error': 'Player not found'}), 404
    
    # Validaciones
    if player.status != 'available':
        return jsonify({'error': 'Player not available'}), 400
    
    squad_count = PlayerContract.query.filter_by(club_id=club.id).count()
    if squad_count >= 18:
        return jsonify({'error': 'Squad is full'}), 400
    
    # Presupuesto ilimitado: permitir fichar sin restricción
    # Crear contrato
    contract = PlayerContract(
        player_id=player.id,
        club_id=club.id,
        contract_type='free_agent',
        salary=0
    )
    
    # No se descuenta presupuesto (infinito)
    player.status = 'signed'
    
    transaction = Transaction(
        club_id=club.id,
        player_id=player.id,
        transaction_type='sign',
        amount=player.value,
        description=f'Fichaje de {player.name}'
    )
    
    db.session.add(contract)
    db.session.add(transaction)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': f'{player.name} signed successfully',
        'available_budget': club.available_budget
    })
