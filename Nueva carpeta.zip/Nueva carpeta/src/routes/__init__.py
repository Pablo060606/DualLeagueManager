"""Blueprints de rutas"""
from src.routes import auth, clubs, market, transfers, stats, public

__all__ = ['auth', 'clubs', 'market', 'transfers', 'stats', 'public']
