"""Rutas de estadísticas"""
from flask import Blueprint, render_template, jsonify
from flask_login import login_required, current_user
from src.database.models import db, Club, Player, PlayerContract
from sqlalchemy import func

bp = Blueprint('stats', __name__, url_prefix='/stats')

@bp.route('/club')
@login_required
def club_stats():
    """Estadísticas del club del usuario"""
    club = Club.query.filter_by(manager_id=current_user.id).first()
    
    if not club:
        return render_template('stats.html', error='No club found')
    
    contracts = PlayerContract.query.filter_by(club_id=club.id).all()
    
    # Calcular estadísticas
    total_players = len(contracts)
    total_value = sum(c.player.value for c in contracts)
    avg_rating = sum(c.player.rating for c in contracts) / total_players if total_players > 0 else 0
    
    # Estadísticas por posición
    position_stats = db.session.query(
        Player.position,
        func.count(PlayerContract.id).label('count'),
        func.avg(Player.rating).label('avg_rating')
    ).join(
        PlayerContract, Player.id == PlayerContract.player_id
    ).filter(
        PlayerContract.club_id == club.id
    ).group_by(Player.position).all()
    
    position_data = {
        'PG': {'count': 0, 'avg_rating': 0},
        'DEF': {'count': 0, 'avg_rating': 0},
        'MED': {'count': 0, 'avg_rating': 0},
        'DEL': {'count': 0, 'avg_rating': 0}
    }
    
    for pos, count, avg_rat in position_stats:
        if pos in position_data:
            position_data[pos] = {
                'count': count,
                'avg_rating': round(avg_rat, 2)
            }
    
    return render_template('stats.html',
                         club=club,
                         total_players=total_players,
                         total_value=total_value,
                         avg_rating=round(avg_rating, 2),
                         available_budget=club.available_budget,
                         position_stats=position_data)

@bp.route('/api/club-stats')
@login_required
def api_club_stats():
    """API: Obtener estadísticas del club"""
    club = Club.query.filter_by(manager_id=current_user.id).first()
    
    if not club:
        return jsonify({'error': 'Club not found'}), 404
    
    contracts = PlayerContract.query.filter_by(club_id=club.id).all()
    total_value = sum(c.player.value for c in contracts)
    avg_rating = sum(c.player.rating for c in contracts) / len(contracts) if contracts else 0
    
    return jsonify({
        'club_id': club.id,
        'club_name': club.name,
        'total_budget': club.budget,
        'available_budget': club.available_budget,
        'squad_size': len(contracts),
        'total_value': total_value,
        'avg_rating': round(avg_rating, 2)
    })
