"""Rutas de gestión de clubes"""
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, abort
from flask_login import login_required, current_user
from src.database.models import db, Club, PlayerContract, Player

bp = Blueprint('clubs', __name__, url_prefix='/clubs')

@bp.route('/dashboard')
@login_required
def dashboard():
    """Dashboard principal del club"""
    if current_user.role == 'player':
        return redirect(url_for('market.players'))

    club = Club.query.filter_by(manager_id=current_user.id).first()
    
    if not club:
        return redirect(url_for('clubs.create'))
    
    squad_count = PlayerContract.query.filter_by(club_id=club.id).count()
    squad_avg_rating = db.session.query(db.func.avg(Player.rating)).join(
        PlayerContract, Player.id == PlayerContract.player_id
    ).filter(PlayerContract.club_id == club.id).scalar() or 0
    
    return render_template('dashboard.html',
                         club=club,
                         squad_count=squad_count,
                         squad_avg_rating=round(squad_avg_rating, 2))

@bp.route('/create', methods=['GET', 'POST'])
@login_required
def create():
    """Crear un nuevo club"""
    if current_user.role == 'player':
        flash('Los jugadores no pueden crear clubes', 'error')
        return redirect(url_for('market.players'))

    # Verificar si el usuario ya tiene un club
    existing_club = Club.query.filter_by(manager_id=current_user.id).first()
    if existing_club:
        flash('Ya tienes un club creado', 'info')
        return redirect(url_for('clubs.dashboard'))
    
    if request.method == 'POST':
        name = (request.form.get('name') or '').strip()
        budget_raw = request.form.get('budget', 5000000)
        
        if not name:
            flash('El nombre del club es requerido', 'error')
            return redirect(url_for('clubs.create'))

        try:
            budget = float(budget_raw)
        except (TypeError, ValueError):
            flash('El presupuesto debe ser un número válido', 'error')
            return redirect(url_for('clubs.create'))

        if budget <= 0:
            flash('El presupuesto debe ser mayor que 0', 'error')
            return redirect(url_for('clubs.create'))
        
        # Verificar si el nombre ya existe
        if Club.query.filter_by(name=name).first():
            flash('Este nombre de club ya existe', 'error')
            return redirect(url_for('clubs.create'))
        
        club = Club(
            name=name,
            manager_id=current_user.id,
            budget=budget,
            available_budget=budget
        )
        
        db.session.add(club)
        db.session.commit()
        
        flash(f'Club {name} creado exitosamente!', 'success')
        return redirect(url_for('clubs.dashboard'))
    
    return render_template('create_club.html')

@bp.route('/<int:club_id>/squad')
def squad(club_id):
    """Ver plantilla del club"""
    club = db.session.get(Club, club_id)
    if not club:
        abort(404)
    contracts = PlayerContract.query.filter_by(club_id=club_id).all()
    
    squad_players = []
    for contract in contracts:
        squad_players.append({
            'player': contract.player,
            'contract': contract
        })
    
    return render_template('squad.html', club=club, squad=squad_players)

@bp.route('/<int:club_id>/stats')
def stats(club_id):
    """Estadísticas del club"""
    club = db.session.get(Club, club_id)
    if not club:
        abort(404)
    
    contracts = PlayerContract.query.filter_by(club_id=club_id).all()
    total_value = sum(c.player.value for c in contracts)
    avg_rating = sum(c.player.rating for c in contracts) / len(contracts) if contracts else 0
    
    return render_template('stats.html',
                         club=club,
                         total_contracts=len(contracts),
                         total_value=total_value,
                         avg_rating=round(avg_rating, 2))

@bp.route('/api/my-club')
@login_required
def api_my_club():
    """API: Obtener el club del usuario actual"""
    club = Club.query.filter_by(manager_id=current_user.id).first()
    
    if not club:
        return jsonify({'error': 'No club found'}), 404
    
    return jsonify({
        'id': club.id,
        'name': club.name,
        'budget': club.budget,
        'available_budget': club.available_budget
    })
