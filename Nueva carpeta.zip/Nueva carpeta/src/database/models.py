from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime

db = SQLAlchemy()

class User(UserMixin, db.Model):
    """Modelo de usuario"""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password = db.Column(db.String(255), nullable=False)
    name = db.Column(db.String(120), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # 'manager' o 'player'
    phone = db.Column(db.String(30), nullable=True)
    city = db.Column(db.String(120), nullable=True)
    birth_date = db.Column(db.Date, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relaciones
    clubs = db.relationship('Club', backref='manager', lazy=True, foreign_keys='Club.manager_id')
    player_profile = db.relationship('Player', backref='user', uselist=False, foreign_keys='Player.user_id')
    
    def __repr__(self):
        return f'<User {self.email}>'


class Club(db.Model):
    """Modelo de club"""
    __tablename__ = 'clubs'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False, unique=True)
    manager_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    budget = db.Column(db.Float, nullable=False)
    available_budget = db.Column(db.Float, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relaciones
    contracts = db.relationship('PlayerContract', backref='club', lazy=True, cascade='all, delete-orphan')
    requests_sent = db.relationship('MarketRequest', foreign_keys='MarketRequest.from_club_id', 
                                    backref='from_club', lazy=True, cascade='all, delete-orphan')
    requests_received = db.relationship('MarketRequest', foreign_keys='MarketRequest.to_club_id',
                                       backref='to_club', lazy=True, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Club {self.name}>'


class Player(db.Model):
    """Modelo de jugador base"""
    __tablename__ = 'players'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    position = db.Column(db.String(20), nullable=False)  # 'PG', 'DEF', 'MED', 'DEL'
    rating = db.Column(db.Float, nullable=False)
    value = db.Column(db.Float, nullable=False)
    league = db.Column(db.String(50), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True, unique=True)
    release_clause = db.Column(db.Float, nullable=True)
    status = db.Column(db.String(20), default='available')  # 'available', 'signed', 'injured'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relaciones
    contracts = db.relationship('PlayerContract', backref='player', lazy=True)
    requests = db.relationship('MarketRequest', backref='player', lazy=True)
    
    def __repr__(self):
        return f'<Player {self.name}>'


class PlayerContract(db.Model):
    """Modelo de contrato de jugador"""
    __tablename__ = 'player_contracts'
    
    id = db.Column(db.Integer, primary_key=True)
    player_id = db.Column(db.Integer, db.ForeignKey('players.id'), nullable=False)
    club_id = db.Column(db.Integer, db.ForeignKey('clubs.id'), nullable=False)
    contract_type = db.Column(db.String(50), nullable=False)  # 'free_agent', 'invited', 'signed'
    salary = db.Column(db.Float, nullable=False, default=0)
    start_date = db.Column(db.DateTime, default=datetime.utcnow)
    end_date = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Contract {self.player_id} - {self.club_id}>'


class MarketRequest(db.Model):
    """Modelo de solicitud de fichaje"""
    __tablename__ = 'market_requests'
    
    id = db.Column(db.Integer, primary_key=True)
    from_club_id = db.Column(db.Integer, db.ForeignKey('clubs.id'), nullable=False)
    to_club_id = db.Column(db.Integer, db.ForeignKey('clubs.id'), nullable=True)
    player_id = db.Column(db.Integer, db.ForeignKey('players.id'), nullable=False)
    request_type = db.Column(db.String(50), nullable=False)  # 'invitation', 'offer', 'clause'
    status = db.Column(db.String(20), default='pending')  # 'pending', 'accepted', 'rejected'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    response_date = db.Column(db.DateTime, nullable=True)
    
    def __repr__(self):
        return f'<Request {self.id}: {self.status}>'


class Transaction(db.Model):
    """Modelo de transacción/movimiento"""
    __tablename__ = 'transactions'
    
    id = db.Column(db.Integer, primary_key=True)
    club_id = db.Column(db.Integer, db.ForeignKey('clubs.id'), nullable=False)
    player_id = db.Column(db.Integer, db.ForeignKey('players.id'), nullable=False)
    transaction_type = db.Column(db.String(50), nullable=False)  # 'sign', 'release', 'clause'
    amount = db.Column(db.Float, nullable=False)
    description = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Transaction {self.transaction_type}: {self.amount}>'


class MembershipRequest(db.Model):
    """Solicitud de vinculación entre club y jugador usuario."""
    __tablename__ = 'membership_requests'

    id = db.Column(db.Integer, primary_key=True)
    club_id = db.Column(db.Integer, db.ForeignKey('clubs.id'), nullable=False, index=True)
    player_id = db.Column(db.Integer, db.ForeignKey('players.id'), nullable=False, index=True)
    initiated_by = db.Column(db.String(20), nullable=False)  # 'club' o 'player'
    request_kind = db.Column(db.String(30), nullable=False)  # 'join_request', 'club_invitation', 'precontract'
    status = db.Column(db.String(20), default='pending', nullable=False)  # 'pending', 'accepted', 'rejected'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    response_date = db.Column(db.DateTime, nullable=True)

    club = db.relationship('Club', backref='membership_requests', lazy=True)
    player = db.relationship('Player', backref='membership_requests', lazy=True)

    def __repr__(self):
        return f'<MembershipRequest {self.id}: {self.request_kind}/{self.status}>'
