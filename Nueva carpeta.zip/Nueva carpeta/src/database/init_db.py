"""Inicialización de la base de datos con datos de ejemplo"""
import os
import sys
from pathlib import Path

# Agregar carpeta src al path
sys.path.insert(0, str(Path(__file__).parent.parent))

from models import db, User, Club, Player, PlayerContract, Transaction
from config import config
from flask import Flask
from werkzeug.security import generate_password_hash

def init_database():
    """Inicializar la base de datos con tablas y datos de ejemplo"""
    
    # Crear aplicación Flask
    app = Flask(__name__)
    app.config.from_object(config['development'])
    
    # Inicializar SQLAlchemy
    db.init_app(app)
    
    with app.app_context():
        # Crear todas las tablas
        print("Creando tablas de base de datos...")
        db.create_all()
        
        # Verificar si ya existen datos
        if User.query.first() is not None:
            print("La base de datos ya contiene datos. Abortando inicialización.")
            return
        
        print("Insertando datos de ejemplo...")
        
        # Crear usuarios de ejemplo
        user1 = User(
            email='manager1@example.com',
            password=generate_password_hash('password123'),
            name='Manager1',
            role='manager'
        )
        
        user2 = User(
            email='manager2@example.com',
            password=generate_password_hash('password123'),
            name='Manager2',
            role='manager'
        )
        
        db.session.add(user1)
        db.session.add(user2)
        db.session.commit()
        
        # Crear clubes
        club1 = Club(
            name='FC Barcelona',
            manager_id=user1.id,
            budget=50000000,
            available_budget=50000000
        )
        
        club2 = Club(
            name='Real Madrid',
            manager_id=user2.id,
            budget=50000000,
            available_budget=50000000
        )
        
        db.session.add(club1)
        db.session.add(club2)
        db.session.commit()
        
        # Crear jugadores disponibles (base de datos de jugadores)
        players_data = [
            # LaLiga
            ('Vinícius Jr.', 'DEL', 8.5, 100000000, 'LaLiga'),
            ('Pedri', 'MED', 8.3, 80000000, 'LaLiga'),
            ('Gavi', 'MED', 8.1, 75000000, 'LaLiga'),
            ('Lewandowski', 'DEL', 8.4, 60000000, 'LaLiga'),
            ('Sergio Busquets', 'MED', 7.8, 40000000, 'LaLiga'),
            
            # Premier League
            ('Harry Kane', 'DEL', 8.6, 120000000, 'Premier League'),
            ('Erling Haaland', 'DEL', 9.0, 150000000, 'Premier League'),
            ('Bruno Fernandes', 'MED', 8.7, 110000000, 'Premier League'),
            ('Jude Bellingham', 'MED', 8.5, 130000000, 'Premier League'),
            ('Kyle Walker', 'DEF', 8.2, 90000000, 'Premier League'),
            
            # Serie A
            ('Lautaro Martínez', 'DEL', 8.4, 100000000, 'Serie A'),
            ('Nicolò Barella', 'MED', 8.3, 95000000, 'Serie A'),
            ('Alessandro Bastoni', 'DEF', 8.1, 80000000, 'Serie A'),
            ('Paulo Dybala', 'DEL', 8.0, 70000000, 'Serie A'),
            ('Samir Handanovic', 'PG', 7.5, 20000000, 'Serie A'),
            
            # Ligue 1
            ('Kylian Mbappé', 'DEL', 9.1, 180000000, 'Ligue 1'),
            ('Eduardo Camavinga', 'MED', 8.2, 85000000, 'Ligue 1'),
            ('Marquinhos', 'DEF', 8.0, 70000000, 'Ligue 1'),
            ('Donnarumma', 'PG', 8.3, 60000000, 'Ligue 1'),
            ('Vitinha', 'MED', 8.1, 65000000, 'Ligue 1'),
            
            # Bundesliga
            ('Florian Wirtz', 'DEL', 8.8, 140000000, 'Bundesliga'),
            ('Jamal Musiala', 'MED', 8.7, 125000000, 'Bundesliga'),
            ('Serge Gnabry', 'DEL', 8.1, 60000000, 'Bundesliga'),
            ('Joshua Kimmich', 'MED', 8.2, 75000000, 'Bundesliga'),
            ('Leon Goretzka', 'MED', 8.0, 65000000, 'Bundesliga'),
        ]
        
        players = []
        for name, position, rating, value, league in players_data:
            player = Player(
                name=name,
                position=position,
                rating=rating,
                value=value,
                league=league,
                status='available'
            )
            players.append(player)
        
        db.session.add_all(players)
        db.session.commit()
        
        print("✓ Base de datos inicializada correctamente")
        print(f"  - {User.query.count()} usuarios creados")
        print(f"  - {Club.query.count()} clubes creados")
        print(f"  - {Player.query.count()} jugadores en mercado")


if __name__ == '__main__':
    init_database()
