# Plan de pruebas automatizadas (Lab 3)

## 1) Pruebas funcionales

- **Unitarias (caja blanca)**: `tests/unit/test_models.py`
  - Representación de modelos y valores por defecto.
- **Integración (caja gris)**: `tests/integration/test_transfers_flow.py`
  - Flujo de login + fichaje por API + persistencia de contrato/transacción.
  - Filtro del mercado para devolver solo jugadores disponibles.
- **Validación (caja negra)**: `tests/validation/test_functional_requirements.py`
  - Restricción de acceso al dashboard sin autenticación.
  - Registro con email duplicado.
  - Límite máximo de 18 jugadores en plantilla.
  - Validación de payload incompleto en API de fichajes.
  - Validación de presupuesto no numérico al crear club.

## 2) Pruebas no funcionales

- `tests/non_functional/test_quality_attributes.py`
  - **Seguridad**: bloqueo de open redirect en login.
  - **Rendimiento básico**: tiempo de respuesta del endpoint de mercado.

## 3) Ejecución

```bash
pytest -q
```
