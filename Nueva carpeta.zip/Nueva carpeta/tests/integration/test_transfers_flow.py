from src.database.models import db, Club, Player, PlayerContract, Transaction


def _login(client, email, password):
    return client.post(
        "/auth/login",
        data={"email": email, "password": password},
        follow_redirects=False,
    )


def test_sign_player_api_creates_club_contract_and_transaction(client, create_user, create_player, app_ctx):
    user = create_user(email="integration@test.com", password="secret123")
    player = create_player(name="Integracion Player", value=2_000_000, status="available")

    login_response = _login(client, user.email, "secret123")
    assert login_response.status_code == 302

    response = client.post("/transfers/api/sign", json={"player_id": player.id})
    assert response.status_code == 200
    payload = response.get_json()
    assert payload["success"] is True

    created_club = Club.query.filter_by(manager_id=user.id).first()
    assert created_club is not None
    assert PlayerContract.query.filter_by(club_id=created_club.id, player_id=player.id).count() == 1
    assert Transaction.query.filter_by(club_id=created_club.id, player_id=player.id, transaction_type="sign").count() == 1
    assert db.session.get(Player, player.id).status == "signed"


def test_market_api_only_returns_available_players(client, create_player, app_ctx):
    create_player(name="Libre", status="available")
    create_player(name="NoLibre", status="signed")

    response = client.get("/market/api/players")
    assert response.status_code == 200
    names = {item["name"] for item in response.get_json()}

    assert "Libre" in names
    assert "NoLibre" not in names
