import time


def _login(client, email, password, next_url=None):
    path = "/auth/login"
    if next_url:
        path = f"/auth/login?next={next_url}"
    return client.post(
        path,
        data={"email": email, "password": password},
        follow_redirects=False,
    )


def test_login_blocks_open_redirects(client, create_user):
    user = create_user(email="security@test.com", password="secret123")

    response = _login(client, user.email, "secret123", "http://evil.example/phishing")
    assert response.status_code == 302
    assert response.headers["Location"].endswith("/clubs/dashboard")


def test_market_api_responds_under_performance_threshold(client, create_player):
    for i in range(300):
        create_player(name=f"Perf Player {i}", status="available")

    start = time.perf_counter()
    response = client.get("/market/api/players")
    elapsed = time.perf_counter() - start

    assert response.status_code == 200
    assert len(response.get_json()) == 300
    assert elapsed < 1.0
