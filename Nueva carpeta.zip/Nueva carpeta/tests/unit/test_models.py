from src.database.models import db, User, Club, Player


def test_user_repr_uses_email(app_ctx):
    user = User(email="unit@test.com", password="hash", name="Unit", role="manager")
    assert repr(user) == "<User unit@test.com>"


def test_club_repr_uses_name(app_ctx):
    club = Club(name="Unit Club", manager_id=1, budget=1000, available_budget=1000)
    assert repr(club) == "<Club Unit Club>"


def test_player_default_status_is_available(app_ctx):
    player = Player(name="Unit Player", position="DEL", rating=7.5, value=1000, league="LaLiga")
    db.session.add(player)
    db.session.commit()

    assert db.session.get(Player, player.id).status == "available"
