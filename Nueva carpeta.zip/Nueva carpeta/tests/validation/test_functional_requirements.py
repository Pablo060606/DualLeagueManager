from src.database.models import db, User, Club, PlayerContract, Player, MembershipRequest


def _login(client, email, password):
    return client.post(
        "/auth/login",
        data={"email": email, "password": password},
        follow_redirects=False,
    )


def test_dashboard_requires_authentication(client):
    response = client.get("/clubs/dashboard", follow_redirects=False)
    assert response.status_code == 302
    assert "/auth/login" in response.headers["Location"]


def test_register_rejects_duplicate_email(client, create_user, app_ctx):
    create_user(email="dup@test.com", password="secret123")

    response = client.post(
        "/auth/register",
        data={
            "email": "dup@test.com",
            "password": "newsecret",
            "name": "Duplicado",
            "role": "manager",
        },
        follow_redirects=True,
    )

    assert response.status_code == 200
    assert User.query.filter_by(email="dup@test.com").count() == 1
    assert b"El email ya est" in response.data


def test_api_sign_rejects_when_squad_is_full(client, create_user, create_club, create_player, add_contract, app_ctx):
    user = create_user(email="full@test.com", password="secret123")
    club = create_club(manager_id=user.id, name="Squad Full FC")

    for i in range(18):
        player = create_player(name=f"Player {i}", status="signed")
        add_contract(player_id=player.id, club_id=club.id)

    available_player = create_player(name="Fichaje Bloqueado", status="available")
    _login(client, user.email, "secret123")

    response = client.post("/transfers/api/sign", json={"player_id": available_player.id})
    assert response.status_code == 400
    assert response.get_json()["error"] == "Squad is full"
    assert PlayerContract.query.filter_by(club_id=club.id).count() == 18


def test_api_sign_rejects_missing_player_id(client, create_user):
    user = create_user(email="missingplayerid@test.com", password="secret123")
    _login(client, user.email, "secret123")

    response = client.post("/transfers/api/sign", json={})
    assert response.status_code == 400
    assert response.get_json()["error"] == "player_id is required"


def test_create_club_rejects_non_numeric_budget(client, create_user):
    user = create_user(email="budget@test.com", password="secret123")
    _login(client, user.email, "secret123")

    response = client.post(
        "/clubs/create",
        data={"name": "Budget FC", "budget": "abc"},
        follow_redirects=True,
    )

    assert response.status_code == 200
    assert Club.query.filter_by(name="Budget FC").first() is None
    assert b"presupuesto debe ser un n" in response.data


def test_player_login_redirects_to_market(client, create_user):
    player_user = create_user(email="player@test.com", password="secret123", role="player")

    response = _login(client, player_user.email, "secret123")
    assert response.status_code == 302
    assert response.headers["Location"].endswith("/market/players")


def test_player_market_is_read_only(client, create_user, create_player):
    player_user = create_user(email="readonly@test.com", password="secret123", role="player")
    create_player(name="Mercado Visible", status="available")
    _login(client, player_user.email, "secret123")

    response = client.get("/market/players")
    assert response.status_code == 200
    assert b"Fichar" not in response.data


def test_player_can_request_join_and_manager_can_accept(client, create_user, create_club, app_ctx):
    manager = create_user(email="manager-accept@test.com", password="secret123", role="manager")
    club = create_club(manager_id=manager.id, name="Aceptacion FC")

    player_user = create_user(email="player-accept@test.com", password="secret123", role="player", name="Player Accept")
    player_profile = Player(
        name="Player Accept",
        position="DEL",
        rating=6.0,
        value=1_000_000,
        league="LaLiga",
        status="available",
        user_id=player_user.id,
        release_clause=5_000_000,
    )
    db.session.add(player_profile)
    db.session.commit()

    _login(client, player_user.email, "secret123")
    response = client.post("/transfers/requests/player-to-club", data={"club_id": club.id}, follow_redirects=True)
    assert response.status_code == 200

    req = MembershipRequest.query.filter_by(club_id=club.id, player_id=player_profile.id, status="pending").first()
    assert req is not None

    client.get("/auth/logout")
    _login(client, manager.email, "secret123")
    response = client.post(
        f"/transfers/requests/{req.id}/respond",
        data={"decision": "accepted"},
        follow_redirects=True,
    )
    assert response.status_code == 200
    assert db.session.get(MembershipRequest, req.id).status == "accepted"
    assert PlayerContract.query.filter_by(club_id=club.id, player_id=player_profile.id).count() == 1
